package com.informatika19100070.MNOERAFDHOL_19100070_DAFTARINFAK.model

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.informatika19100070.MNOERAFDHOL_19100070_DAFTARINFAK.R

class responactioninfak : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_responactioninfak)
    }
}